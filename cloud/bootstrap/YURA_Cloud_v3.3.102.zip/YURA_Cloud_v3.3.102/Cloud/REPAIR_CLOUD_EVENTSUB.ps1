﻿param(
    [string]$CloudUrl = "https://yura-cloud.heiyeshi.workers.dev"
)
$ErrorActionPreference = "Stop"
$secure = Read-Host "ADMIN_KEY" -AsSecureString
$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try {
    $key = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
    $headers = @{ Authorization = "Bearer $key" }
    $result = Invoke-RestMethod -Method Post -Uri ($CloudUrl.TrimEnd('/') + '/api/admin/register-eventsub') -Headers $headers -ContentType 'application/json' -Body '{}'
    $result | ConvertTo-Json -Depth 10
    Write-Host ""
    Write-Host "EventSub repair request completed. channel.chat.message must be enabled or verification_pending." -ForegroundColor Green
} finally {
    if ($ptr -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}
