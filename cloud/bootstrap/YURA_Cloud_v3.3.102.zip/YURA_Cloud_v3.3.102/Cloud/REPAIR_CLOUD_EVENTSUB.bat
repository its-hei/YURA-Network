@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0REPAIR_CLOUD_EVENTSUB.ps1"
echo.
pause
