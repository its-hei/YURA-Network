﻿$ErrorActionPreference='Stop'
$settingsDir=Join-Path $env:APPDATA 'YURA'
$settingsPath=Join-Path $settingsDir 'settings.json'
$markerPath=Join-Path $settingsDir 'cloud-mode.json'
New-Item -ItemType Directory -Force -Path $settingsDir | Out-Null
$marker=[ordered]@{ YuraCloudEnabled=$false; YuraCloudBaseUrl='' }
$marker | ConvertTo-Json | Set-Content -LiteralPath $markerPath -Encoding UTF8
if (Test-Path $settingsPath) {
  $obj=Get-Content $settingsPath -Raw | ConvertFrom-Json
  $obj | Add-Member -NotePropertyName YuraCloudEnabled -NotePropertyValue $false -Force
  $obj | Add-Member -NotePropertyName YuraCloudBaseUrl -NotePropertyValue '' -Force
  $obj | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $settingsPath -Encoding UTF8
}
Write-Host 'YURA Cloud disabled. Local Event Host still will NOT auto-start; start it manually only for fallback testing.' -ForegroundColor Yellow
