param(
    [switch]$NonInteractive,
    [switch]$RequireCloudMode
)

$ErrorActionPreference = 'Stop'
$CloudRoot = Join-Path $PSScriptRoot 'yura-cloud'
$WranglerPath = Join-Path $CloudRoot 'wrangler.toml'
$YuraDir = Join-Path $env:APPDATA 'YURA'
$MarkerPath = Join-Path $YuraDir 'cloud-mode.json'
$ProfilePath = Join-Path $YuraDir 'cloud-install.json'
$LogPath = Join-Path $YuraDir 'cloud-update.log'

New-Item -ItemType Directory -Force -Path $YuraDir | Out-Null

function Log([string]$Message) {
    $line = "[{0}] {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
    Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8
}

function Read-JsonFile([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    try { return Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json }
    catch { return $null }
}

function Read-TomlString([string]$Text, [string]$Name) {
    $m = [regex]::Match($Text, '(?m)^\s*' + [regex]::Escape($Name) + '\s*=\s*"([^"]*)"\s*$')
    if ($m.Success) { return $m.Groups[1].Value }
    return ''
}

function Set-TomlString([string]$Text, [string]$Name, [string]$Value) {
    $pattern = '(?m)^(\s*' + [regex]::Escape($Name) + '\s*=\s*)"[^"]*"(\s*)$'
    if ([regex]::IsMatch($Text, $pattern)) {
        return [regex]::Replace($Text, $pattern, ('$1"' + $Value + '"$2'), 1)
    }
    return $Text
}

if (-not (Test-Path -LiteralPath $WranglerPath)) {
    throw "Missing Cloudflare config: $WranglerPath"
}

$marker = Read-JsonFile $MarkerPath
$cloudEnabled = $false
$markerUrl = ''
if ($null -ne $marker) {
    try { $cloudEnabled = [bool]$marker.YuraCloudEnabled } catch {}
    try { $markerUrl = [string]$marker.YuraCloudBaseUrl } catch {}
}
if ($RequireCloudMode -and -not $cloudEnabled) {
    Write-Host 'YURA Cloud Mode is disabled; Cloud update skipped.' -ForegroundColor DarkYellow
    return
}

$toml = Get-Content -LiteralPath $WranglerPath -Raw
$profile = Read-JsonFile $ProfilePath

if ($null -eq $profile) {
    $workerName = Read-TomlString $toml 'name'
    $databaseName = Read-TomlString $toml 'database_name'
    $databaseId = Read-TomlString $toml 'database_id'
    $tomlUrl = Read-TomlString $toml 'CLOUD_PUBLIC_URL'
    $cloudUrl = if (-not [string]::IsNullOrWhiteSpace($markerUrl)) { $markerUrl.Trim().TrimEnd('/') } else { $tomlUrl.Trim().TrimEnd('/') }

    if ([string]::IsNullOrWhiteSpace($workerName)) { $workerName = 'yura-cloud' }
    if ([string]::IsNullOrWhiteSpace($databaseName)) { $databaseName = 'yura-cloud' }
    if ([string]::IsNullOrWhiteSpace($databaseId) -or $databaseId -like 'REPLACE_*') {
        throw 'Cloud profile is missing a D1 database_id. First-time Cloud setup is required once.'
    }
    if ([string]::IsNullOrWhiteSpace($cloudUrl)) {
        throw 'Cloud profile is missing the Worker URL. Enable Cloud Mode once before automatic updates.'
    }

    $profile = [ordered]@{
        version = 1
        workerName = $workerName
        databaseName = $databaseName
        databaseId = $databaseId
        cloudUrl = $cloudUrl
    }
    $profile | ConvertTo-Json | Set-Content -LiteralPath $ProfilePath -Encoding UTF8
    Log "created persistent cloud profile worker=$workerName db=$databaseName url=$cloudUrl"
}

$workerName = [string]$profile.workerName
$databaseName = [string]$profile.databaseName
$databaseId = [string]$profile.databaseId
$cloudUrl = [string]$profile.cloudUrl
if (-not [string]::IsNullOrWhiteSpace($markerUrl)) { $cloudUrl = $markerUrl.Trim().TrimEnd('/') }

if ([string]::IsNullOrWhiteSpace($workerName)) { $workerName = 'yura-cloud' }
if ([string]::IsNullOrWhiteSpace($databaseName)) { $databaseName = 'yura-cloud' }
if ([string]::IsNullOrWhiteSpace($databaseId)) { throw 'Persistent Cloud profile has no databaseId.' }
if ([string]::IsNullOrWhiteSpace($cloudUrl)) { throw 'Persistent Cloud profile has no cloudUrl.' }

# Rehydrate each new version from the machine-stable profile. This means future ZIPs
# do not require repeating D1 creation, database IDs, URLs, OAuth seed or secrets.
$toml = Set-TomlString $toml 'name' $workerName
$toml = Set-TomlString $toml 'database_name' $databaseName
$toml = Set-TomlString $toml 'database_id' $databaseId
$toml = Set-TomlString $toml 'CLOUD_PUBLIC_URL' $cloudUrl
Set-Content -LiteralPath $WranglerPath -Value $toml -Encoding UTF8

# Keep profile refreshed in case the URL marker was changed deliberately.
[ordered]@{
    version = 1
    workerName = $workerName
    databaseName = $databaseName
    databaseId = $databaseId
    cloudUrl = $cloudUrl
} | ConvertTo-Json | Set-Content -LiteralPath $ProfilePath -Encoding UTF8

if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
    throw 'npm/Node.js not found. Desktop build is still usable, but Cloud cannot be updated automatically.'
}
if (-not (Get-Command npx -ErrorAction SilentlyContinue)) {
    throw 'npx not found. Desktop build is still usable, but Cloud cannot be updated automatically.'
}

Push-Location $CloudRoot
try {
    Write-Host 'Cloud Mode detected - updating existing YURA Cloud...' -ForegroundColor Cyan
    Write-Host "  Worker: $workerName" -ForegroundColor DarkGray
    Write-Host "  D1:     $databaseName" -ForegroundColor DarkGray
    Write-Host "  URL:    $cloudUrl" -ForegroundColor DarkGray

    & npm install --no-fund --no-audit
    if ($LASTEXITCODE -ne 0) { throw "npm install failed with exit code $LASTEXITCODE" }

    # Wrangler login is machine-persistent. A normal YURA version update must never ask
    # again for Twitch secrets, ADMIN_KEY or database setup.
    & npx wrangler whoami | Out-Host
    if ($LASTEXITCODE -ne 0) {
        throw 'Wrangler authentication expired. Run `npx wrangler login` once, then BUILD_PORTABLE.bat again.'
    }

    # v0.5.6.33: mirror the existing Windows-protected Discord bot credential into a
    # Cloudflare Worker secret. It never touches settings.json or the release ZIP.
    try {
        $privateSecretsPath = Join-Path $YuraDir 'private.secrets.bin'
        if (Test-Path -LiteralPath $privateSecretsPath) {
            Add-Type -AssemblyName System.Security
            $protectedBytes = [System.IO.File]::ReadAllBytes($privateSecretsPath)
            $clearBytes = [System.Security.Cryptography.ProtectedData]::Unprotect(
                $protectedBytes,
                $null,
                [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
            $privateJson = [System.Text.Encoding]::UTF8.GetString($clearBytes) | ConvertFrom-Json
            $discordToken = [string]$privateJson.DiscordBotToken
            if (-not [string]::IsNullOrWhiteSpace($discordToken)) {
                $discordToken.Trim() | & npx wrangler secret put DISCORD_BOT_TOKEN | Out-Host
                if ($LASTEXITCODE -eq 0) {
                    Write-Host 'Discord leave watcher credential synced to YURA Cloud.' -ForegroundColor Green
                    Log 'discord bot secret sync OK'
                } else {
                    Write-Host 'Discord leave watcher secret sync failed; desktop Discord still works.' -ForegroundColor Yellow
                    Log "discord bot secret sync failed exit=$LASTEXITCODE"
                }
            } else {
                Write-Host 'Discord bot token is not stored yet; 24/7 leave watcher will wait for it.' -ForegroundColor DarkYellow
            }
        }
    }
    catch {
        Write-Host "Discord secret sync warning: $($_.Exception.Message)" -ForegroundColor Yellow
        Log "discord secret sync warning: $($_.Exception.Message)"
    }

    # Apply only new migrations. D1 keeps its migration journal, so old migrations are not rerun.
    $migrationCmd = "echo y|npx wrangler d1 migrations apply $databaseName --remote"
    & cmd.exe /d /s /c $migrationCmd
    if ($LASTEXITCODE -ne 0) { throw "D1 migration check/apply failed with exit code $LASTEXITCODE" }

    & npx wrangler deploy
    if ($LASTEXITCODE -ne 0) { throw "wrangler deploy failed with exit code $LASTEXITCODE" }

    try {
        $health = Invoke-RestMethod -Method Get -Uri ($cloudUrl.TrimEnd('/') + '/health') -TimeoutSec 15
        if ($health.ok -eq $true) {
            $ver = if ($health.version) { [string]$health.version } else { '?' }
            Write-Host "YURA Cloud READY - backend v$ver" -ForegroundColor Green
            Log "cloud deploy OK backend=$ver url=$cloudUrl"
        } else {
            Write-Host 'Cloud deployed, but /health did not return ok=true yet.' -ForegroundColor Yellow
            Log 'cloud deploy completed but health response was not ok=true'
        }
    }
    catch {
        Write-Host "Cloud deployed; health check warning: $($_.Exception.Message)" -ForegroundColor Yellow
        Log "cloud deploy completed; health warning: $($_.Exception.Message)"
    }

    Write-Host 'Existing D1 data, Worker secrets, OAuth tokens and EventSub are preserved.' -ForegroundColor Green
    Write-Host 'No create/import/seed/repair steps are required for normal YURA updates.' -ForegroundColor Green
}
finally {
    Pop-Location
}
