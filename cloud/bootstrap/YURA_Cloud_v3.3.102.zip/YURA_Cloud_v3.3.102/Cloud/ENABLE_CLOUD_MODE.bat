﻿@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0ENABLE_CLOUD_MODE.ps1"
pause
