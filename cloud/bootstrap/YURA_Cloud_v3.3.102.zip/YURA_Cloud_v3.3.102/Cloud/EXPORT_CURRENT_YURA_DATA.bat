﻿@echo off
setlocal
set ROOT=%~dp0..
set EXE=%ROOT%\YURA_Portable\App\YURA.exe
if not exist "%EXE%" (
  echo YURA.exe not found. Build the portable package first with BUILD_PORTABLE.bat.
  pause
  exit /b 1
)
"%EXE%" --export-cloud-migration "%~dp0yura-cloud-import.json"
if errorlevel 1 (
  echo Export failed. Check %%APPDATA%%\YURA\eventhost-startup.log
  pause
  exit /b 1
)
echo.
echo Export ready: %~dp0yura-cloud-import.json
pause
