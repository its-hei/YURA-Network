# Minimal Cloud architecture (v3.2.45)

The Worker owns only features that must survive with the PC off: 24/7 commands, YURA Points/watchtime/presence and website ranking data. Timers, dashboard history, Discord Live remains local/manual. Community checks are limited to one combined Followers + Subs + Discord report per 24h. DEDGE/DEDGES follow the same per-command CLOUD 24/7 / STREAM ON policy as other commands.

# YURA Cloud 3.2.45

## 3.2.44 — raffle cancel hardening
- `!cancelraffle` is resolved before automatic raffle finalization, so it cannot lose a race with the finisher.
- An active raffle can be cancelled even if the cached STREAM LIVE flag is stale.
- AUTORAFFLE now has a real 6-second active state and only announces winners after the countdown, which makes it cancellable.
- `!join` is ignored during AUTORAFFLE because participants are captured from current viewers at start.


## 0.5.6.60 — per-command availability
- Fixed and custom commands persist independent `CLOUD 24/7` (`alwaysOnline`) and `STREAM ON` (`streamOn`) flags.
- Worker executes a command when Cloud is enabled for that command, or when STREAM ON is enabled and Twitch stream state is LIVE.
- DEDGE/DEDGES follow the normal command policy. The old runtime module stays disabled; only a tiny 3-counter command state is synchronized on seed/local edits and after matching chat commands.

## 0.5.6.58 — final Minimal Cloud / fallback probe
- The scheduled minute job keeps only EventSub self-healing, presence/watchtime/points sampling and active raffle completion. It performs one combined community report at most once per 24h; timers remain local/manual.
- `/health` performs one tiny `SELECT 1` D1 probe. Desktop calls it once per minute so D1 quota exhaustion/outages activate local fallback without the old heavy `/api/status` polling.
- Stale D1 flags cannot re-enable Cloud timers, deaths, stream events or dashboard history; those flags fail closed before any D1 lookup.
- Public `/api/leaderboard-revision` and `/api/leaderboard` remain the live website source. Manual `SYNC NOW` publishes the independent GitHub `live-data/leaderboard.json` LAST SYNC snapshot.

## 0.5.6.44 — batched presence accrual
- The Worker still samples current chatters each minute, but stores that minute in one compact `presence_pending_json` row.
- Account watchtime, viewing points and transaction rows are flushed every 10 minutes using the accumulated sampled seconds.
- A `stream.offline` EventSub notification flushes the final partial interval immediately.
- The point rate remains based on `POINTS_BASE_PER_10M`, including the existing remainder model.
- `/health` exposes `presence_interval_minutes: 10`; Discord leave polling remains daily.


## 0.5.6.43 — D1 write reduction
- Discord member-leave polling runs once per day at 00:10 UTC.
- The main cron remains every minute for presence accrual, timers and EventSub repair.
- This avoids rebuilding the Discord member snapshot roughly 1,440 times per day.

## 0.5.6.42 — cloud runtime

- 24/7 Cloud timers synchronized from Desktop.
- Legacy dedicated DEDGE/DEDGES state synchronization (the commands themselves use the normal command policy).
- Stream online/offline EventSub handling and optional Discord LIVE notification.
- Cloud event history + aggregated dashboard endpoint.
- Independent module switches stored in D1 meta.


## 0.5.6.34 — command routing fix
- OWN alias parser accepts spaces, commas, semicolons and new lines.
- OWN, REGULAR and POINTS are executed by the Worker 24/7 while each command is enabled.
- The Desktop is only the editor/synchronizer in Cloud Mode; it does not need to stay open.
- `regular_commands_ready=true` is exposed in Cloud status.

## 0.5.6.20 — stream start status
- `/api/status` now exposes `stream_started_at_utc` for the current Twitch broadcast.
- Scheduled presence sampling and Twitch `stream.online` / `stream.offline` EventSub events keep that timestamp current.

## 0.5.6.18 — CRIT payout tiers
- `critWinPercent` still controls the total CRIT WIN chance.
- After CRIT triggers, payout tier is fixed to 90% = 2x, 9% = 3x, 1% = 5x.
- Chat output includes the rolled multiplier.

## 0.5.6.17 — configurable gamble odds + CRIT WIN
- `!gamble` reads `winPercent` and `critWinPercent` from the command settings synced by YURA Desktop.
- CRIT WIN awards 2× the wager; normal WIN awards 1× the wager; the remaining probability is LOSS.
- Desktop ACCRUAL controls WIN/LOSS percentage; the Worker defaults to 50% only when no synced value exists.

## Normal updates after the first setup

The long Cloudflare/Twitch setup is ONE-TIME ONLY. After Cloud Mode has been configured once, YURA stores the non-secret Worker/D1 identity in `%APPDATA%\YURA\cloud-install.json`; Cloudflare keeps secrets and D1 data remotely.

For future versions, normally do only:

```text
BUILD_PORTABLE.bat
```

When Cloud Mode is enabled, the builder automatically restores the same Worker/D1 configuration, applies only pending D1 migrations, deploys the new Worker code and checks `/health`. You do **not** repeat `d1 create`, secret entry, OAuth seed, import, `ENABLE_CLOUD_MODE` or EventSub repair.

`Cloud\DEPLOY_CLOUD_UPDATE.bat` is only a manual retry button if the automatic Cloud update could not run (for example temporary Internet failure or an expired Wrangler login).

The first-time setup instructions below are retained only for a fresh Windows/Cloudflare installation.

# YURA Cloud 0.5.6.4

## 0.5.6.4 — cloud accrual status

- `/api/status` oraz `/health` pokazują teraz `present_count`, ostatni sample, punkty i watchtime z ostatniej próbki.
- Cron zapisuje status także gdy kanał jest OFFLINE, dzięki czemu Desktop nie myli braku lokalnego Event Hosta z awarią punktów.
- Desktop ACCRUAL w Cloud Mode czyta status Workera; `REFRESH STATUS` nie uruchamia lokalnego Hosta.


Pierwszy backend 24/7 dla YURY. Z założenia działa na Cloudflare Workers + D1 i przejmuje część, która nie powinna zależeć od włączonego PC:

- Twitch EventSub webhook (`channel.chat.message`, `stream.online`, `stream.offline`),
- odpowiedzi jako YuraNetworkTTV,
- `!points / !pkt / !yura`, `!watchtime / !czas`, `!top`, `!gamble`, `!add`, `!remove`,
- +10 YURA za wiadomość,
- minutowy Cron do obecności / watchtime / punktów za oglądanie,
- D1 jako wspólna baza online,
- publiczne `/api/accounts` dla YURA Desktop i strony,
- migracja istniejących punktów/watchtime z lokalnego `yura-points.db`.

## 1. Wymagania

- konto Cloudflare,
- Node.js 20+,
- działająca autoryzacja Twitch broadcastera oraz YuraNetworkTTV w YURA Desktop; w 0.5.6.4 bot wymaga `user:read:chat` oraz `moderator:read:chatters`, więc po aktualizacji wejdź raz w Settings → Connections → Twitch i wykonaj upgrade autoryzacji bota,
- YuraNetworkTTV jako moderator kanału (Cloud używa jego tokena do `Get Chatters`).

## 2. Cloudflare

W tym katalogu:

```powershell
npm install
npx wrangler login
npx wrangler d1 create yura-cloud
```

Skopiuj `database_id` z wyniku do `wrangler.toml` w miejsce `REPLACE_WITH_D1_DATABASE_ID`, następnie:

```powershell
npm run db:migrate
```

Ustaw sekrety Workera:

```powershell
npx wrangler secret put TWITCH_CLIENT_ID
npx wrangler secret put TWITCH_CLIENT_SECRET
npx wrangler secret put TWITCH_BROADCASTER_ID
npx wrangler secret put TWITCH_BOT_USER_ID
npx wrangler secret put EVENTSUB_SECRET
npx wrangler secret put ADMIN_KEY
```

`EVENTSUB_SECRET` i `ADMIN_KEY` ustaw jako dwa różne, losowe długie ciągi. Nie wrzucaj ich do repo.

Potem:

```powershell
npm run deploy
```

Zapisz adres w stylu `https://yura-cloud.<konto>.workers.dev`.

## 3. Przenieś OAuth z YURA bez wypisywania tokenów na ekran

Najpierw zbuduj normalnie portable przez `BUILD_PORTABLE.bat`, potem uruchom:

`..\SEED_TWITCH_AUTH_TO_CLOUD.bat`

Skrypt pyta tylko o URL Workera i `ADMIN_KEY`. YURA Desktop czyta tokeny z Windows DPAPI i wysyła je bezpośrednio HTTPS do Workera. Tokeny nie są zapisywane w jawnym pliku. Worker zapisuje granty w D1 i sam odświeża je po wygaśnięciu.

Ta sama operacja rejestruje webhooki EventSub.

## 4. Przenieś punkty + watchtime

Uruchom:

`..\EXPORT_CURRENT_YURA_DATA.bat`

Powstanie `Cloud\yura-cloud-import.json`. Potem:

```powershell
.\IMPORT_TO_CLOUD.ps1 -CloudUrl "https://...workers.dev" -AdminKey "TWOJ_ADMIN_KEY"
```

Import jest UPSERT-em po loginie. Watchtime trafia jako seed, więc nie zerujemy historii StreamElements/YURY.

## 5. Test

Otwórz:

- `/health`
- `/api/accounts`

Po wpisaniu `!points` na Twitchu YuraNetworkTTV powinien odpowiedzieć nawet przy wyłączonym YURA Desktop.

## 6. Przełączenie Desktopu na Cloud

Uruchom:

```powershell
.\ENABLE_CLOUD_MODE.ps1 -CloudUrl "https://...workers.dev"
```

Po restarcie Desktop:

- nie uruchamia lokalnego Event Hosta,
- zakładka YURA Points czyta ranking/watchtime z `/api/accounts`,
- OBS, Stream Deck, muzyka i urządzenia nadal działają lokalnie. Avatar działa w osobnym programie Yura Avatar.

Powrót awaryjny:

```powershell
.\DISABLE_CLOUD_MODE.ps1
```

Po restarcie wraca lokalny Event Host.

## Ważne na etap 0.5.6.4

To jest migracja rdzenia ekonomii i bota do chmury. Desktop czyta już dane z Cloud, ale część lokalnych paneli administracyjnych (np. ręczne operacje wykonywane bezpośrednio z GUI) nadal jest lokalna. Do momentu przepięcia tych mutacji na API, administrację punktami wykonuj komendami `!add` / `!remove` lub Cloud API. Kolejny krok to pełne przepięcie edycji Monthly VIP, manual bots i Account na REST API.


## v3.3.97 — GAINS EXP i ranking rekordów

`GET /api/ranking` sortuje `gains` według `monthlyExp` i udostępnia `records.bestMonthlyGain` (najwyższy miesięczny EXP w istniejących checkpointach) oraz `records.permanentVipWinners` (wyłącznie `status=granted`). Nie zmienia schematu D1.
