# Y.U.R.A. v3.3.100 — Statystyki i stałe punkty

- Salda YURA Points są stałe, bez końca miesiąca. Endpoint resetowania odrzuca żądania bez zapisu.
- GAINS EXP nadal nalicza się i rotuje miesięcznie (VIP jest oddzielną nagrodą).
- Nowa publiczna zakładka Statystyki pobiera /api/public-stats z Cloud.
- Rejestrowanie wiadomości z EventSub z unikalnym ID, minimum 10 wiadomości na uczestnika.
- Gamble ALL liczone osobno od innych stawek, wynik zwycięstwo/przegrana.
- Długość followa jest wyświetlana wyłącznie gdy synchronizacja followers zapisała prawdziwą datę.
- Poprzednia historia lokalna Desktop nie jest automatycznie importowana do Cloud; bieżący Cloud zachowuje historię cloud_events jeśli istnieje.

Wymagane wdrożenie Cloud wraz z migracją 0010; gotowy EXE nie jest częścią tego wydania źródłowego.
