# DEDGE Cloud Worker fix — YURA 3.2.99

## Deployment (Windows PowerShell)
1. Back up your current Cloudflare D1 database and existing local YURA death counters first.
2. Open PowerShell in this `Cloud/yura-cloud` directory.
3. `npm install`
4. `npx tsc --noEmit`
5. `npx wrangler whoami` — authenticate if prompted.
6. Check `wrangler.toml` bindings and environment, so you do not deploy to a different worker.
7. `npm run deploy`
8. Restart YURA; test `!dedge` once, verify the counter increases by exactly one.

The patch removes the silent 'death_state_ready' early return; preserves existing cloud counts and increments via one D1 UPDATE, preventing lost updates. If the cloud never received an initial desktop seed, it initializes the cloud count at 0 before incrementing; compare with the desktop counter before testing in production. No change to your Cloudflare deployment has been made by this package. This package does NOT fix Follow username handling.
