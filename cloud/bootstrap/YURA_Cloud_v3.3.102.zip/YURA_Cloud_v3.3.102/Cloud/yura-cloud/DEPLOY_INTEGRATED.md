# YURA integrated source / Worker deployment

This archive contains the complete desktop source AND Cloudflare Worker source.

1. Backup your D1 database and app configuration first.
2. Inside `Cloud/yura-cloud`, run `npm install`, `npx tsc --noEmit`, `npx wrangler whoami`, and `npm run deploy` (requires your own Cloudflare authorization).
3. Compile desktop on Windows using .NET SDK and the WPF project (`dotnet build Yura.Desktop.csproj -c Release`).
4. Verify that the published Cloud Worker URL matches YURA Settings, then run `!dedge` from Twitch chat and check the D1 death counter.
5. Test a NEW real Twitch Follow and inspect Activity Feed. If identity is absent from Streamer.bot's WebSocket event itself, the desktop logs `SB FOLLOW IDENTITY MISSING` and refuses to save an anonymous user; the Streamer.bot action history fields may still contain the identity in a separate context.

Not validated against live Twitch or Cloudflare from this environment. No compiled Windows EXE is included.
