﻿param(
  [Parameter(Mandatory=$true)][string]$CloudUrl,
  [Parameter(Mandatory=$true)][string]$AdminKey,
  [string]$JsonPath = "$PSScriptRoot\yura-cloud-import.json"
)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $JsonPath)) { throw "Missing export file: $JsonPath" }
$body = Get-Content -LiteralPath $JsonPath -Raw
$headers = @{ Authorization = "Bearer $AdminKey" }
$result = Invoke-RestMethod -Method Post -Uri ($CloudUrl.TrimEnd('/') + '/api/admin/import') -Headers $headers -ContentType 'application/json' -Body $body
$result | ConvertTo-Json -Depth 5
