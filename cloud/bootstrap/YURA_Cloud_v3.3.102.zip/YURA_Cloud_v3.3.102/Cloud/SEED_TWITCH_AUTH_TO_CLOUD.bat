﻿@echo off
setlocal
set /p CLOUDURL=YURA Cloud URL (https://...workers.dev): 
set /p ADMINKEY=ADMIN_KEY: 
set ROOT=%~dp0..
set EXE=%ROOT%\YURA_Portable\App\YURA.exe
if not exist "%EXE%" (
  echo YURA.exe not found. Build portable first with BUILD_PORTABLE.bat.
  pause
  exit /b 1
)
"%EXE%" --seed-cloud-oauth "%CLOUDURL%" "%ADMINKEY%"
if errorlevel 1 (
  echo Seed failed. Check %%APPDATA%%\YURA\eventhost-startup.log
  pause
  exit /b 1
)
echo Twitch OAuth copied directly from Windows-protected YURA storage to YURA Cloud over HTTPS.
echo EventSub registration was requested too.
pause
