﻿param([string]$CloudUrl="https://yura-cloud.heiyeshi.workers.dev")
$ErrorActionPreference='Stop'
$url=$CloudUrl.Trim().TrimEnd('/')
if (-not ($url -match '^https://')) { throw 'CloudUrl must start with https://' }
$settingsDir=Join-Path $env:APPDATA 'YURA'
$settingsPath=Join-Path $settingsDir 'settings.json'
$markerPath=Join-Path $settingsDir 'cloud-mode.json'
New-Item -ItemType Directory -Force -Path $settingsDir | Out-Null

# Separate marker = source of truth for Cloud mode. It survives a running Desktop
# saving an older in-memory settings.json while the app is closing.
$marker=[ordered]@{ YuraCloudEnabled=$true; YuraCloudBaseUrl=$url }
$marker | ConvertTo-Json | Set-Content -LiteralPath $markerPath -Encoding UTF8

if (Test-Path $settingsPath) { $obj=Get-Content $settingsPath -Raw | ConvertFrom-Json } else { $obj=[pscustomobject]@{} }
$obj | Add-Member -NotePropertyName YuraCloudEnabled -NotePropertyValue $true -Force
$obj | Add-Member -NotePropertyName YuraCloudBaseUrl -NotePropertyValue $url -Force
$obj | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $settingsPath -Encoding UTF8

# Persist the Cloud installation identity outside version folders. Normal future YURA
# versions can restore their wrangler.toml from this profile and update the SAME Worker/D1.
try {
  $wranglerPath=Join-Path $PSScriptRoot 'yura-cloud\wrangler.toml'
  if (Test-Path -LiteralPath $wranglerPath) {
    $toml=Get-Content -LiteralPath $wranglerPath -Raw
    function ReadToml([string]$name) {
      $m=[regex]::Match($toml, '(?m)^\s*'+[regex]::Escape($name)+'\s*=\s*"([^"]*)"\s*$')
      if ($m.Success) { return $m.Groups[1].Value }
      return ''
    }
    $workerName=ReadToml 'name'
    $databaseName=ReadToml 'database_name'
    $databaseId=ReadToml 'database_id'
    if ([string]::IsNullOrWhiteSpace($workerName)) { $workerName='yura-cloud' }
    if ([string]::IsNullOrWhiteSpace($databaseName)) { $databaseName='yura-cloud' }
    if (-not [string]::IsNullOrWhiteSpace($databaseId) -and $databaseId -notlike 'REPLACE_*') {
      [ordered]@{
        version=1
        workerName=$workerName
        databaseName=$databaseName
        databaseId=$databaseId
        cloudUrl=$url
      } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $settingsDir 'cloud-install.json') -Encoding UTF8
    }
  }
} catch {
  Write-Host "Cloud profile warning: $($_.Exception.Message)" -ForegroundColor DarkYellow
}

Write-Host "YURA Cloud enabled: $url" -ForegroundColor Green
Write-Host "Persistent marker: $markerPath" -ForegroundColor DarkGray
Write-Host 'Restart YURA Desktop. Cloud mode will survive Desktop shutdown/settings saves.'
