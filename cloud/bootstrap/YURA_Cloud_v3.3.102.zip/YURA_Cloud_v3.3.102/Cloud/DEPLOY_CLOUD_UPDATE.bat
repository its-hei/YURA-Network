@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Update-YuraCloud.ps1"
if errorlevel 1 goto :fail
echo.
echo YURA Cloud update OK.
pause
exit /b 0
:fail
echo.
echo YURA Cloud update FAILED. Desktop/local build is not affected.
echo Check %%APPDATA%%\YURA\cloud-update.log or run npx wrangler login if authorization expired.
pause
exit /b 1
