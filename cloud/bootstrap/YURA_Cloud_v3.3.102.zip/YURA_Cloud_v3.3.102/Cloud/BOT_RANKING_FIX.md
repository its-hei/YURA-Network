# YURA Cloud — permanent bot exclusion from !top

The point accounts are never deleted. `!top` and public rankings exclude Nightbot, Sery_Bot, StreamElements, the YURA bot account, and known service bots **before** applying the top-5 limit. Both `login` and `display_name` are examined.

The normal `BUILD_PORTABLE.bat` updates the existing Cloud Worker automatically when Cloud Mode is enabled. Confirm the message `Cloud update finished`. Otherwise run `Cloud/DEPLOY_CLOUD_UPDATE.bat` after ensuring your Cloudflare session is authorized, and inspect `%AppData%\YURA\cloud-update.log`. No new D1 database, migrations, secrets, or account reset are needed for this patch.
