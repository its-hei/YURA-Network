Y.U.R.A. Cloud v3.3.102 — Pokémon Collection i avatar batching

Co nowego:
- GET /api/pokemon/collection — pelna publiczna kolekcja przypisanych Pokemonow (nick, ID, nazwa, data zapisu), maksymalnie 1000.
- GET /api/avatars?logins=user1,user2 — avatary Twitch dla maksymalnie 20 widzow jednym zapytaniem do Twitch Helix, cache 6 godzin. Nie ujawnia tokenow.
- Obecna logika !pokemon (darmowe pierwsze losowanie) i !pokeroll (5000 YURA Points) nie jest zmieniana.
- Zero nowych migracji D1; dotychczasowe punkty, XP, konta i przypisane Pokemony sa zachowane.

Instalacja: rozpakuj ZIP, uruchom UPDATE_CLOUD.bat na Windows. Zaloguj sie Cloudflare Wrangler, jesli poprosi. Weryfikacja po wdrozeniu: /health, /api/pokemon/collection i /api/avatars?logins=heiyeshi.

Strona www korzysta tymczasowo z /api/ranking jako zapasowego zrodla przypisan Pokemonow, ale pelne nazwy Pokemonow i wydajne avatary beda dostepne po aktualizacji Cloud.
