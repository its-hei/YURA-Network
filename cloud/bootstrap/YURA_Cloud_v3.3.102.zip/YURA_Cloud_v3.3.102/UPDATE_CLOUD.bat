@echo off
cd /d "%~dp0"
call "%~dp0Cloud\DEPLOY_CLOUD_UPDATE.bat"
